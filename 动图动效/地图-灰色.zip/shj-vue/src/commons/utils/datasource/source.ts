import { isArray } from 'lodash'
import { parseCSV, parseExcel, parseJSON } from './file'
import { parseStaticData } from './static'
import { parseVariableData } from './variable'
import { parseAPIPort } from './api'
import { parseUrlData } from './url'


window.SHJDatasourceV2 = ({ sources, callback, tId, isStore = false, noUseMapping = false, isInterval = true }) => {
    if (window.SHJDatasourceV2Timer === undefined) {
        window.SHJDatasourceV2Timer = []
    }
    if (sources && isArray(sources) && sources.length > 0) {
        sources.forEach((item) => {
            if (isInterval) {
                const { source } = item
                const currentTimerId = `${tId}-${item.id}`
                const currentTimerObj = window.SHJDatasourceV2Timer.findIndex(i => i.id === currentTimerId)
                if (currentTimerObj !== -1) {
                    clearInterval(window.SHJDatasourceV2Timer[currentTimerObj].timer)
                    window.SHJDatasourceV2Timer.splice(currentTimerObj, 1)
                }
                if (source.isAutoUpdate) {
                    const timer = setInterval(() => {
                        parseDataSources(item, isStore, noUseMapping, (data: any) => {
                            callback && callback(data)
                        })
                    }, source.autoUpdateTime * 1000)
                    window.SHJDatasourceV2Timer.push({ id: currentTimerId, timer })
                }
            }
            parseDataSources(item, isStore, noUseMapping, (data: any) => {
                callback && callback(data)
            })
        })
    } else {
        callback && callback([])
    }
}

const parseDataSources = (sources: any, isStore: boolean = false, noUseMapping: boolean = false, callback: Function) => {
    if (sources) {
        let taskData = null
        const { source, id } = sources
        if (source.type === 'url') taskData = parseUrlData(sources, id, noUseMapping)
        if (source.type === 'static') taskData = parseStaticData(sources, id, noUseMapping)
        if (source.type === 'variable') taskData = parseVariableData(sources, id, noUseMapping)
        if (source.type === 'api') taskData = parseAPIPort(sources, id, noUseMapping)
        if (source.type === 'csv') taskData = parseCSV(sources, id, noUseMapping)
        if (source.type === 'json') taskData = parseJSON(sources, id, noUseMapping)
        if (source.type === 'excel') taskData = parseExcel(sources, id, noUseMapping)

        if (taskData) {
            taskData.then((data: any) => {
                if (!noUseMapping) {
                    callback && callback(data.finalKeyData)
                }
                if (noUseMapping) {
                    callback && callback(data.noMappingData)
                }
            })
        }
    }
}