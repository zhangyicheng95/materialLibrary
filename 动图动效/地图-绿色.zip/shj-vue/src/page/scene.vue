<script lang="ts" setup>
/** 3D行政边界（省、市、县） **/
import { storeToRefs } from 'pinia'
import { nextTick, onMounted } from 'vue'
import { registerComponentRef } from '@/commons/utils/refs/index'
import { usePageStore } from '@/commons/stores/pageStore'

const useInitScene = () => {
    const pageStore = usePageStore()
    const { currentPage } = storeToRefs(pageStore)

    onMounted(() => {
        nextTick(() => {
            /** 全局事件 页面加载完成时 */
            window.SHJParseEvent(currentPage.value.globalEvent, 'on-page-loaded', null)
        })
    })

    return { currentPage }
}

const { currentPage } = useInitScene()

/** 配置参数 */
const sceneOption = {"backButtonLeft":50,"backButtonBottom":5,"debugger":false,"orbitControls":{"panSpeed":1,"minPolarAngle":0,"maxPolarAngle":75,"enablePan":true,"minDistance":50,"maxDistance":300,"enableDamping":true,"enableZoom":true,"zoomSpeed":1},"widgets":[{"defaultColor":"#212121","name":"全国空气等级","labelStyle":{"fontFamily":"SHJ-SourceHanSansSC-Regular-otf","top":50,"color":"#FFFFFF","left":80,"gap":16,"colorStyle":{"borderRadius":0,"width":14,"height":6},"fontSize":12,"fontStyle":"normal","direction":"column"},"_sourceId":"6acha","rules":[{"min":0,"color":"#7FF08C","max":100,"label":"轻微"},{"min":101,"color":"#5FD96E","max":201,"label":"一般"},{"min":202,"color":"#3EB049","max":302,"label":"中等"},{"min":303,"color":"#289E35","max":403,"label":"较大"},{"min":404,"color":"#0C941C","max":504,"label":"严重"}],"id":"ieibd","type":"regionalLevel","opacity":0.5,"isHide":false}],"scene":{"geojson":"","translateZ":0,"isDrilling":false,"defaultMapAdcode":100000,"background":"#020A07","translateY":0,"translateX":0,"defaultMap":"china","x":0,"y":0,"z":0,"isBackground":true},"light":{"pointLight2":{"intensity":60,"color":"#ffffff","distance":30,"show":true,"x":-4,"y":8,"z":43},"ambientLight":{"intensity":1,"color":"#FFFFFF","show":true},"directionalLight":{"intensity":2,"color":"#ffffff","show":true,"position":{"x":-22,"y":128,"z":-20},"target":{"position":{"x":0,"y":0,"z":0}}},"pointLight1":{"intensity":60,"color":"#ffffff","distance":24,"show":true,"x":1,"y":19,"z":7}},"backButtonCss":{"backgroundColor":"#1F5EFF","borderColor":"#0088FFC3","fontFamily":"SHJ-SourceHanSansSC-Regular-otf","color":"#FFFFFF","borderRadius":4,"backgroundImage":"","borderWidth":1,"backgroundSize":"cover","fontSize":12,"fontStyle":"normal","borderStyle":"solid","fontWeight":600},"backButton":true,"particle":{"material":{"size":10,"color":"#FFFFFF","opacity":0.3},"num":10,"show":true,"range":200,"dir":"up","speed":0.1},"floor":{"quan":{"color":"#007BFF","show":true},"gaoguang":{"color":"#394D41","show":true},"gridRipple":{"diffuseWidth":20,"color":"#566A78","diffuseOpacity":0.5,"alphaMap":"/map3d/gridRippleAlphaMap.png","repeat":100,"show":true,"diffuseSpeed":30,"diffuseColor":"#566A78","opacity":0.1,"map":"/map3d/gridRippleMap.png"},"rotateBorder":{"rotateBorder1":{"size":1.18,"color":"#445057","texture":"/map3d/rotateBorder1Map.png","show":true,"rotateSpeed":1,"opacity":0.2},"rotateBorder2":{"size":1.12,"color":"#445057","texture":"/map3d/rotateBorder2Map.png","show":true,"rotateSpeed":-4,"opacity":0.4}}},"camera":{"position":{"x":0,"y":127,"z":105}},"widgetControlStyle":{"backgroundColor":"#00000000","borderColor":"#5B687559","color":"#D9D9D9","backgroundImage":"","show":false,"active":{"backgroundColor":"#00000000","borderColor":"#498B91","color":"#E8E8E8","backgroundImage":"","borderWidth":1,"fontSize":12,"fontStyle":"normal","borderStyle":"solid","fontWeight":600},"fontStyle":"normal","hover":{"backgroundColor":"#00000000","borderColor":"#498B91","color":"#E8E8E8","backgroundImage":"","borderWidth":1,"fontSize":12,"fontStyle":"normal","borderStyle":"solid","fontWeight":600},"fontFamily":"SHJ-DreamHanSansCN-W1-ttf","top":50,"borderRadius":4,"left":95,"borderWidth":1,"gap":12,"width":100,"backgroundSize":"cover","fontSize":12,"borderStyle":"solid","fontWeight":600,"direction":"column","height":26},"map":{"hoverLineColor":"#CCCCCC","depth":4,"titleLabel":{"offsetX":0,"fontFamily":"SHJ-SourceHanSansSC-Bold-otf","offsetY":3,"color":"#FFFFFF","bottom":2,"show":true,"fontSize":46,"gaodeAPI":"f7d75cd912376e5ade47187998ebbd31"},"backgroundImg":{"color":"#FFFFFF","src":"https://lganv-1304359499.cos.ap-beijing.myqcloud.com/lg_cos_static/system/scene/map3d/004_bg.jpg","alphaMap":"https://lganv-1304359499.cos.ap-beijing.myqcloud.com/lg_cos_static/system/scene/map3d/004_bg.jpg","rotation":[90,-180,180],"show":true,"scale":[0.42000000000000004,0.42000000000000004,0.42000000000000004],"position":[-8.7,0.10000000000000003,11.7],"opacity":0.8},"mirrorShow":false,"sideMaterial":{"color":"#548A5E","opacity":0.8,"map":"/map3d/sideMap.png"},"arealabel":{"fontFamily":"SHJ-SourceHanSansSC-Regular-otf","color":"#FFFFFF","bottom":2,"show":true,"fontSize":12},"lineColor":"#CCCCCC","topMaterial":{"emissive":"#000000","color":"#C9FFEA","hoverOpacity":1,"normalMap":"/map3d/topNormal.jpg","opacity":1,"map":"/map3d/004_map.jpg"},"storkeAnimation":{"color":"#FFFFFF","top":1,"texture":"/map3d/pathLine.png","radius":0.2,"speed":0.3,"segments":1000},"hoverDepth":1.5}}
/** 数据源 */
const sceneSources = [{"name":"地域等级分布","id":"6acha","source":{"mapping":[{"mapping":"name","name":"name","label":"地域名称","type":"string","status":false},{"mapping":"value","name":"value","label":"值","type":"number","status":false}],"static":[{"name":"河南省","value":450},{"name":"新疆维吾尔自治区","value":50},{"name":"西藏自治区","value":150},{"name":"青海省","value":150},{"name":"云南省","value":350},{"name":"四川省","value":150},{"name":"甘肃省","value":150},{"name":"宁夏回族自治区","value":150},{"name":"陕西省","value":150},{"name":"重庆市","value":350},{"name":"贵州省","value":350},{"name":"广西壮族自治区","value":250},{"name":"广东省","value":250},{"name":"海南省","value":50},{"name":"香港特别行政区","value":50},{"name":"澳门特别行政区","value":50},{"name":"湖南省","value":450},{"name":"湖北省","value":450},{"name":"山西省","value":150},{"name":"内蒙古自治区","value":150},{"name":"河北省","value":150},{"name":"山东省","value":150},{"name":"安徽省","value":450},{"name":"江西省","value":450},{"name":"福建省","value":250},{"name":"台湾省","value":250},{"name":"浙江省","value":250},{"name":"江苏省","value":250},{"name":"上海市","value":150},{"name":"山东省","value":150},{"name":"北京市","value":150},{"name":"天津市","value":150},{"name":"辽宁省","value":150},{"name":"吉林省","value":150},{"name":"黑龙江省","value":150}],"isAutoUpdate":false,"autoUpdateTime":60,"type":"static"}}]
</script>
<template>
    <div class="shj-scene">
        <!-- 使用@shjjs/visual-ui全局组件，basic-option暴漏所有参数可修改，sources为指定数据源 -->
        <zv-scene-map3d
            :ref="registerComponentRef(`scene-map3d-7`)"
            :basic-option="sceneOption"
            :sources="sceneSources"
            :use-events="currentPage.globalEvent"
        ></zv-scene-map3d>
    </div>
</template>
<style lang="scss" scoped>
.shj-scene {
    width: 100%;
    height: 100%;
    position: absolute;
    z-index: -1;
}
</style>